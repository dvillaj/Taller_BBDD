--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.movimiento DROP CONSTRAINT movimiento_id_consejero_fkey;
ALTER TABLE ONLY public.movimiento DROP CONSTRAINT movimiento_id_comercio_fkey;
ALTER TABLE ONLY public.comercio DROP CONSTRAINT comercio_id_actividad_fkey;
ALTER TABLE ONLY public.movimiento DROP CONSTRAINT pk_movimiento;
ALTER TABLE ONLY public.consejero DROP CONSTRAINT pk_consejero;
ALTER TABLE ONLY public.comercio DROP CONSTRAINT pk_comercio;
ALTER TABLE ONLY public.actividad DROP CONSTRAINT pk_actividad;
DROP TABLE public.movimiento;
DROP TABLE public.consejero;
DROP TABLE public.comercio;
DROP TABLE public.actividad;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: actividad; Type: TABLE; Schema: public; Owner: learner; Tablespace: 
--

CREATE TABLE actividad (
    id_actividad integer NOT NULL,
    actividad character varying(200)
);


ALTER TABLE public.actividad OWNER TO learner;

--
-- Name: comercio; Type: TABLE; Schema: public; Owner: learner; Tablespace: 
--

CREATE TABLE comercio (
    id_comercio integer NOT NULL,
    comercio character varying(200),
    actividad_completa character varying(200),
    id_actividad integer
);


ALTER TABLE public.comercio OWNER TO learner;

--
-- Name: consejero; Type: TABLE; Schema: public; Owner: learner; Tablespace: 
--

CREATE TABLE consejero (
    id_consejero integer NOT NULL,
    nombre character varying(200),
    funcion character varying(40),
    organizacion character varying(200)
);


ALTER TABLE public.consejero OWNER TO learner;

--
-- Name: movimiento; Type: TABLE; Schema: public; Owner: learner; Tablespace: 
--

CREATE TABLE movimiento (
    id_movimiento integer NOT NULL,
    fecha date NOT NULL,
    hora integer NOT NULL,
    minuto integer NOT NULL,
    importe numeric NOT NULL,
    id_consejero integer NOT NULL,
    id_comercio integer NOT NULL
);


ALTER TABLE public.movimiento OWNER TO learner;

--
-- Data for Name: actividad; Type: TABLE DATA; Schema: public; Owner: learner
--

COPY actividad (id_actividad, actividad) FROM stdin;
\.
COPY actividad (id_actividad, actividad) FROM '$$PATH$$/1989.dat';

--
-- Data for Name: comercio; Type: TABLE DATA; Schema: public; Owner: learner
--

COPY comercio (id_comercio, comercio, actividad_completa, id_actividad) FROM stdin;
\.
COPY comercio (id_comercio, comercio, actividad_completa, id_actividad) FROM '$$PATH$$/1990.dat';

--
-- Data for Name: consejero; Type: TABLE DATA; Schema: public; Owner: learner
--

COPY consejero (id_consejero, nombre, funcion, organizacion) FROM stdin;
\.
COPY consejero (id_consejero, nombre, funcion, organizacion) FROM '$$PATH$$/1988.dat';

--
-- Data for Name: movimiento; Type: TABLE DATA; Schema: public; Owner: learner
--

COPY movimiento (id_movimiento, fecha, hora, minuto, importe, id_consejero, id_comercio) FROM stdin;
\.
COPY movimiento (id_movimiento, fecha, hora, minuto, importe, id_consejero, id_comercio) FROM '$$PATH$$/1991.dat';

--
-- Name: pk_actividad; Type: CONSTRAINT; Schema: public; Owner: learner; Tablespace: 
--

ALTER TABLE ONLY actividad
    ADD CONSTRAINT pk_actividad PRIMARY KEY (id_actividad);


--
-- Name: pk_comercio; Type: CONSTRAINT; Schema: public; Owner: learner; Tablespace: 
--

ALTER TABLE ONLY comercio
    ADD CONSTRAINT pk_comercio PRIMARY KEY (id_comercio);


--
-- Name: pk_consejero; Type: CONSTRAINT; Schema: public; Owner: learner; Tablespace: 
--

ALTER TABLE ONLY consejero
    ADD CONSTRAINT pk_consejero PRIMARY KEY (id_consejero);


--
-- Name: pk_movimiento; Type: CONSTRAINT; Schema: public; Owner: learner; Tablespace: 
--

ALTER TABLE ONLY movimiento
    ADD CONSTRAINT pk_movimiento UNIQUE (id_movimiento);


--
-- Name: comercio_id_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: learner
--

ALTER TABLE ONLY comercio
    ADD CONSTRAINT comercio_id_actividad_fkey FOREIGN KEY (id_actividad) REFERENCES actividad(id_actividad);


--
-- Name: movimiento_id_comercio_fkey; Type: FK CONSTRAINT; Schema: public; Owner: learner
--

ALTER TABLE ONLY movimiento
    ADD CONSTRAINT movimiento_id_comercio_fkey FOREIGN KEY (id_comercio) REFERENCES comercio(id_comercio);


--
-- Name: movimiento_id_consejero_fkey; Type: FK CONSTRAINT; Schema: public; Owner: learner
--

ALTER TABLE ONLY movimiento
    ADD CONSTRAINT movimiento_id_consejero_fkey FOREIGN KEY (id_consejero) REFERENCES consejero(id_consejero);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

